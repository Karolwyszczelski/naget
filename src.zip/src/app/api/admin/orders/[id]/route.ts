// app/api/admin/orders/[id]/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import nodemailer from "nodemailer";

type OrderStatus = "new" | "in_progress" | "done" | "cancelled";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !serviceKey) {
  throw new Error(
    "Brak NEXT_PUBLIC_SUPABASE_URL lub SUPABASE_SERVICE_ROLE_KEY dla admin API."
  );
}

const supabase = createClient(supabaseUrl, serviceKey, {
  auth: { persistSession: false },
});

function parseNumber(value: unknown): number {
  if (typeof value === "number") return value;
  if (typeof value === "string") return parseFloat(value) || 0;
  return 0;
}

type RouteContext = {
  params: Promise<{ id: string }>;
};

type PatchPayload = {
  status?: OrderStatus;
  internalNote?: string;
  sendEmail?: boolean;
  emailMessage?: string;
};

// -------------------- GET – szczegóły zamówienia --------------------

export async function GET(_req: NextRequest, { params }: RouteContext) {
  const { id: publicId } = await params;

  try {
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select("*")
      .eq("public_id", publicId)
      .single();

    if (orderError || !order) {
      console.error("GET order error", orderError);
      return NextResponse.json({ error: "Zamówienie nie istnieje." }, { status: 404 });
    }

    const { data: items, error: itemsError } = await supabase
      .from("order_items")
      .select("*")
      .eq("order_id", order.id);

    if (itemsError) {
      console.error("GET order items error", itemsError);
      return NextResponse.json(
        { error: "Nie udało się pobrać pozycji zamówienia." },
        { status: 500 }
      );
    }

    const detail = {
      id: order.public_id as string,
      createdAt: order.created_at as string,
      status: order.status as OrderStatus,
      currency: (order.currency as string) || "PLN",
      totalAmount: parseNumber(order.grand_total),
      cartTotal: parseNumber(order.cart_total),
      deliveryTotal: parseNumber(order.delivery_total),
      discountTotal: parseNumber(order.discount_total),
      customer: {
        type: order.customer_type as string | null,
        firstName: order.first_name as string | null,
        lastName: order.last_name as string | null,
        companyName: order.company_name as string | null,
        nip: order.nip as string | null,
        email: order.email as string | null,
        phone: order.phone as string | null,
        addressLine1: order.address_line1 as string | null,
        addressLine2: order.address_line2 as string | null,
        postalCode: order.postal_code as string | null,
        city: order.city as string | null,
        country: order.country as string | null,
      },
      delivery: {
        method: order.delivery_method as string | null,
        note: order.delivery_note as string | null,
      },
      items:
        (items ?? []).map((item: any) => ({
          id: item.id as string,
          productId: item.product_id as string,
          name: item.name as string,
          series: item.series as string,
          unitPrice: parseNumber(item.unit_price),
          quantity: Number(item.quantity ?? 0),
          config: item.config,
        })) ?? [],
      internalNote: (order.notes as string | null) ?? null,
      customerNote: (order.delivery_note as string | null) ?? null,
    };

    return NextResponse.json({ order: detail });
  } catch (error) {
    console.error("GET /api/admin/orders/[id] unexpected error:", error);
    return NextResponse.json(
      { error: "Nieoczekiwany błąd podczas pobierania zamówienia." },
      { status: 500 }
    );
  }
}

// -------------------- PATCH – zmiana statusu / notatki + mail --------------------

async function sendStatusEmail(args: {
  to?: string | null;
  publicId: string;
  newStatus: OrderStatus;
  grandTotal: number;
  currency: string;
  customerFirstName?: string | null;
  customerLastName?: string | null;
  customMessage?: string;
}) {
  const { to } = args;
  if (!to) return;

  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT ?? "465");
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;
  const from = process.env.SMTP_FROM || '"Sklep Naget" <no-reply@naget.pl>';

  if (!host || !user || !pass) {
    console.warn("Brak konfiguracji SMTP – e-mail nie został wysłany.");
    return;
  }

  const transporter = nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });

  const statusLabelMap: Record<OrderStatus, string> = {
    new: "nowe",
    in_progress: "w realizacji",
    done: "zrealizowane",
    cancelled: "anulowane",
  };

  const greetingName = (args.customerFirstName || args.customerLastName)
    ? `${args.customerFirstName ?? ""} ${args.customerLastName ?? ""}`.trim()
    : "";

  const subject = `NAGET – aktualizacja statusu zamówienia ${args.publicId}`;
  const statusText = statusLabelMap[args.newStatus];
  const totalLabel = args.grandTotal.toLocaleString("pl-PL", {
    style: "currency",
    currency: args.currency,
  });

  const customBlock = (args.customMessage ?? "").trim();

  const textLines = [
    greetingName ? `Dzień dobry ${greetingName},` : "Dzień dobry,",
    "",
    `Status Twojego zamówienia ${args.publicId} został zmieniony na: ${statusText}.`,
    `Wartość zamówienia: ${totalLabel}.`,
    customBlock && "",
    customBlock,
    "",
    "Pozdrawiamy,",
    "Sklep NAGET",
  ].filter(Boolean);

  const text = textLines.join("\n");

  const html = textLines
    .map((line) => (line === "" ? "<br />" : `<p>${line}</p>`))
    .join("");

  try {
    await transporter.sendMail({
      from,
      to,
      subject,
      text,
      html,
    });
  } catch (error) {
    console.error("Błąd wysyłki maila statusowego:", error);
  }
}

export async function PATCH(req: NextRequest, { params }: RouteContext) {
  const { id: publicId } = await params;

  let payload: PatchPayload = {};
  try {
    payload = (await req.json()) as PatchPayload;
  } catch {
    // ignore – traktuj jak pusty body
  }

  try {
    // pobieramy zamówienie (do aktualizacji + do maila)
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select(
        `
        id,
        public_id,
        email,
        first_name,
        last_name,
        status,
        notes,
        grand_total,
        currency
      `
      )
      .eq("public_id", publicId)
      .single();

    if (orderError || !order) {
      console.error("PATCH order fetch error:", orderError);
      return NextResponse.json({ error: "Zamówienie nie istnieje." }, { status: 404 });
    }

    const updates: Record<string, any> = {};
    let newStatus = order.status as OrderStatus;

    if (payload.status && payload.status !== order.status) {
      newStatus = payload.status;
      updates.status = payload.status;
    }

    if (typeof payload.internalNote === "string") {
      updates.notes = payload.internalNote;
    }

    if (Object.keys(updates).length > 0) {
      const { error: updateError } = await supabase
        .from("orders")
        .update(updates)
        .eq("public_id", publicId);

      if (updateError) {
        console.error("PATCH update error:", updateError);
        return NextResponse.json(
          { error: "Nie udało się zaktualizować zamówienia." },
          { status: 500 }
        );
      }
    }

    // mail do klienta (opcjonalnie)
    if (payload.sendEmail) {
      await sendStatusEmail({
        to: order.email as string | undefined,
        publicId,
        newStatus,
        grandTotal: parseNumber(order.grand_total),
        currency: (order.currency as string) || "PLN",
        customerFirstName: order.first_name as string | null,
        customerLastName: order.last_name as string | null,
        customMessage: payload.emailMessage,
      });
    }

    return NextResponse.json({
      ok: true,
      status: newStatus,
      internalNote:
        typeof payload.internalNote === "string"
          ? payload.internalNote
          : (order.notes as string | null) ?? null,
    });
  } catch (error) {
    console.error("PATCH /api/admin/orders/[id] unexpected error:", error);
    return NextResponse.json(
      { error: "Nieoczekiwany błąd podczas zapisu zamówienia." },
      { status: 500 }
    );
  }
}
