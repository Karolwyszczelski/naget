"use client";

import {
  createContext,
  useContext,
  useMemo,
  useState,
  useEffect,
  ReactNode,
} from "react";

export type CartItemConfig = Record<string, unknown>;

export type CartItem = {
  id: string;
  productId: string;
  name: string;
  series: "stand-up" | "slab-fence" | "addons";
  unitPrice: number;
  quantity: number;
  config?: CartItemConfig;
};

type CartContextValue = {
  items: CartItem[];
  totalAmount: number;
  totalQuantity: number;
  addItem: (item: Omit<CartItem, "id">) => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
  updateQuantity: (id: string, quantity: number) => void;
};

const CartContext = createContext<CartContextValue | undefined>(undefined);

const STORAGE_KEY = "naget-cart-v1";

function loadCartFromStorage(): CartItem[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed;
  } catch {
    return [];
  }
}

function saveCartToStorage(items: CartItem[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  } catch {
    // ignorujemy błędy localStorage
  }
}

export function CartProvider({ children }: { children: ReactNode }) {
  // LAZY INIT – od razu próbujemy czytać localStorage na kliencie
  const [items, setItems] = useState<CartItem[]>(() => loadCartFromStorage());

  // zapis do localStorage przy każdej zmianie koszyka
  useEffect(() => {
    saveCartToStorage(items);
  }, [items]);

  const addItem: CartContextValue["addItem"] = (item) => {
    setItems((prev) => {
      // jeśli konfiguracja identyczna – zwiększ ilość
      const existingIndex = prev.findIndex(
        (p) =>
          p.productId === item.productId &&
          JSON.stringify(p.config ?? {}) === JSON.stringify(item.config ?? {})
      );

      if (existingIndex === -1) {
        return [
          ...prev,
          {
            ...item,
            id: crypto.randomUUID(),
          },
        ];
      }

      const copy = [...prev];
      copy[existingIndex] = {
        ...copy[existingIndex],
        quantity: copy[existingIndex].quantity + item.quantity,
      };
      return copy;
    });
  };

  const removeItem: CartContextValue["removeItem"] = (id) => {
    setItems((prev) => prev.filter((item) => item.id !== id));
  };

  const clearCart: CartContextValue["clearCart"] = () => {
    setItems([]);
  };

  const updateQuantity: CartContextValue["updateQuantity"] = (
    id,
    quantity
  ) => {
    setItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, quantity: Math.max(1, quantity) } : item
      )
    );
  };

  const totalAmount = useMemo(
    () => items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0),
    [items]
  );

  const totalQuantity = useMemo(
    () => items.reduce((sum, item) => sum + item.quantity, 0),
    [items]
  );

  const value: CartContextValue = {
    items,
    totalAmount,
    totalQuantity,
    addItem,
    removeItem,
    clearCart,
    updateQuantity,
  };

  return (
    <CartContext.Provider value={value}>{children}</CartContext.Provider>
  );
}

export function useCart(): CartContextValue {
  const ctx = useContext(CartContext);
  if (!ctx) {
    throw new Error("useCart must be used within CartProvider");
  }
  return ctx;
}
