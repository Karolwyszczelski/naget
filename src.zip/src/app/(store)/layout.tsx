import type { Metadata } from "next";
import "../globals.css";
import Navbar from "../components/navbar";
import { CartProvider } from "./CartContext";
import Footer from "../components/Footer";

export const metadata: Metadata = {
  title: "Sklep Naget",
  description: "Nowoczesne bramy, furtki i zadaszenia Naget.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pl">
      <body>
        <CartProvider>
          <Navbar />
          <main>{children}</main>
          <Footer />
        </CartProvider>
      </body>
    </html>
  );
}
