import type { Metadata } from "next";
import "./globals.css";
import Navbar from "./components/navbar";
import Footer from "./components/Footer";
import { CartProvider } from "../app/(store)/CartContext";

export const metadata: Metadata = {
  title: "Naget – konfigurator ogrodzeń",
  description:
    "Sklep i konfiguratory ogrodzeń pionowych Stand Up oraz pełnych zabudów Slab Fence.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="pl">
      <body className="bg-background text-foreground antialiased">
        <CartProvider>
          <main className=" min-h-[calc(100vh-200px)]">
            {children}
          </main>
        </CartProvider>
      </body>
    </html>
  );
}
